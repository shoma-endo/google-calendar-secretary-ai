import React, { useEffect, useState } from 'react';
import {
  Users,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  Search,
} from 'lucide-react';
import InvoiceTable from '../components/InvoiceTable';
import { Invoice } from '../types/invoice';

const AdminDashboard = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [filteredInvoices, setFilteredInvoices] = useState<Invoice[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState({
    users: 128,
    pending: 0,
    approved: 0,
    rejected: 0
  });

  useEffect(() => {
    const storedInvoices = JSON.parse(localStorage.getItem('invoices') || '[]');
    setInvoices(storedInvoices);
    setFilteredInvoices(storedInvoices);

    // 統計情報を計算
    const newStats = storedInvoices.reduce((acc: typeof stats, invoice: Invoice) => {
      if (invoice.status === '審査待ち') acc.pending++;
      if (invoice.status === '承認済み') acc.approved++;
      if (invoice.status === '却下') acc.rejected++;
      return acc;
    }, {
      users: 128,
      pending: 0,
      approved: 0,
      rejected: 0
    });

    setStats(newStats);
  }, []);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value;
    setSearchTerm(term);
    
    const filtered = invoices.filter(invoice => 
      invoice.number.toLowerCase().includes(term.toLowerCase()) ||
      invoice.amount.toLowerCase().includes(term.toLowerCase())
    );
    setFilteredInvoices(filtered);
  };

  const handleStatusChange = (invoiceId: number, newStatus: string) => {
    const updatedInvoices = invoices.map(invoice => {
      if (invoice.id === invoiceId) {
        const statusColor = newStatus === '承認済み' ? 'green' : 'red';
        return { ...invoice, status: newStatus, statusColor };
      }
      return invoice;
    });

    localStorage.setItem('invoices', JSON.stringify(updatedInvoices));
    setInvoices(updatedInvoices);
    setFilteredInvoices(updatedInvoices);

    // 統計情報を更新
    const newStats = updatedInvoices.reduce((acc: typeof stats, invoice: Invoice) => {
      if (invoice.status === '審査待ち') acc.pending++;
      if (invoice.status === '承認済み') acc.approved++;
      if (invoice.status === '却下') acc.rejected++;
      return acc;
    }, {
      users: stats.users,
      pending: 0,
      approved: 0,
      rejected: 0
    });

    setStats(newStats);
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
            管理者ダッシュボード
          </h2>
        </div>
      </div>

      <div className="mt-8">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Users className="h-6 w-6 text-gray-400" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      登録ユーザー数
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">{stats.users}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Clock className="h-6 w-6 text-yellow-400" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      審査待ち
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">{stats.pending}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-6 w-6 text-green-400" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      承認済み
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">{stats.approved}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <XCircle className="h-6 w-6 text-red-400" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      却下
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">{stats.rejected}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                請求書一覧
              </h3>
              <div className="flex-1 max-w-lg ml-4">
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 sm:text-sm border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="請求書を検索..."
                    value={searchTerm}
                    onChange={handleSearch}
                  />
                </div>
              </div>
            </div>
            
            <InvoiceTable 
              invoices={filteredInvoices}
              isAdmin={true}
              onStatusChange={handleStatusChange}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;